﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

/// <summary>
/// author: neko_hat
/// </summary>

namespace BruteForce
{
    class Program
    {
        #region Private variables
        // the secret password which we will try to find via brute force
        private static string inputStr = "";
        private static int password = 0;
        private static string? result { get; set; }
        private static bool isMatched = false;
        private static bool viewSetting = false;

        /* The length of the charactersToTest Array is stored in a
         * additional variable to increase performance  */
        private static int charactersToTestLength = 0;
        private static long computedKeys = 0;

        /* An array containing the characters which will be used to create the brute force keys,
         * if less characters are used (e.g. only lower case chars) the faster the password is matched  */
        private static char[] charactersToTest =
        {
            '0','1','2','3','4','5', '6','7','8','9'
        };
        #endregion

        public static void Main()
        {

            Console.WriteLine("Input Target User name...");
            inputStr = Console.ReadLine();
 
            if(inputStr != null)
            {
                if(inputStr == "")
                {
                    Console.WriteLine("Do Input Correct User name!");
                    Console.WriteLine("Press Enter to EXIT...");
                    Console.ReadLine();
                    return;
                }
                Console.WriteLine("Do you want to see a using key? y/n (default : no)");
                
                viewSelect:
                string? select = Console.ReadLine();
                if(select != null)
                {
                    switch(select)
                    {
                        case "y":
                            viewSetting = true;
                            break;
                        case "Y":
                            viewSetting = true;
                            break;
                        case "n":
                            viewSetting = false;
                            break;
                        case "N":
                            viewSetting = false;
                            break;
                        case "":
                            break;
                        default:
                            Console.WriteLine("Input Only y/n!");
                            goto viewSelect;
                    }
                }

                MakeSerial(inputStr);
            }

            var timeStarted = DateTime.Now;
            Console.WriteLine("Start BruteForce - {0}", timeStarted.ToString());
            Console.WriteLine("Target : {0}", password);

            // The length of the array is stored permanently during runtime
            charactersToTestLength = charactersToTest.Length;

            // The length of the password is unknown, so we have to run trough the full search space
            var estimatedPasswordLength = 5;

            while (!isMatched)
            {
                startBruteForce(estimatedPasswordLength);
            }

            Console.WriteLine("Password matched. - {0}", DateTime.Now.ToString());
            Console.WriteLine("Time Passed {0}s", DateTime.Now.Subtract(timeStarted).ToString());
            Console.WriteLine("Resolved Password: {0}", result);
            Console.WriteLine("Computed keys: {0}", computedKeys);

            Console.WriteLine("Press Enter to EXIT...");
            Console.ReadLine();
        }

        #region private method
        private static char[] createCharArray(int length, char defaultChar)
        {
            return (from c in new char[length] select defaultChar).ToArray();
        }

        private static void startBruteForce(int keyLength)
        {
            var keyChars = createCharArray(keyLength, charactersToTest[0]);
            // The index of the last character will be stored for slight perfomance improvement
            var indexOfLastChar = keyLength - 1;
            createNewKey(0, keyChars, keyLength, indexOfLastChar);
        }

        /// <summary>
        /// This is the main workhorse, it creates new keys and compares them to the password until the password
        /// is matched or all keys of the current key length have been checked
        /// </summary>
        /// <param name="currentCharPosition">The position of the char which is replaced by new characters currently</param>
        /// <param name="keyChars">The current key represented as char array</param>
        /// <param name="keyLength">The length of the key</param>
        /// <param name="indexOfLastChar">The index of the last character of the key</param>
        private static void createNewKey(int currentCharPosition, char[]? keyChars, int keyLength, int indexOfLastChar)
        {
            if(keyChars == null)
            {
                Console.WriteLine("Key Gen Erro!");
                return;
            }
            var nextCharPosition = currentCharPosition + 1;
            // We are looping trough the full length of our charactersToTest array
            for (int i = 0; i < charactersToTestLength; i++)
            {
                /* The character at the currentCharPosition will be replaced by a
                 * new character from the charactersToTest array => a new key combination will be created */
                keyChars[currentCharPosition] = charactersToTest[i];

                // The method calls itself recursively until all positions of the key char array have been replaced
                if (currentCharPosition < indexOfLastChar)
                {
                    //Console.WriteLine(keyChars);
                    createNewKey(nextCharPosition, keyChars, keyLength, indexOfLastChar);
                }
                else
                {
                    // A new key has been created, remove this counter to improve performance
                    computedKeys++;

                    /* The char array will be converted to a string and compared to the password. If the password
                     * is matched the loop breaks and the password is stored as result. */
                    if(viewSetting)
                        Console.WriteLine("Using Key : {0} Encryption Key : {1}", new string(keyChars), encryptKey(keyChars));
                    if ((encryptKey(keyChars)) == password)
                    {
                        if (!isMatched)
                        {
                            isMatched = true;
                            result = new String(keyChars);
                        }
                        return;
                    }
                }
            }
        }

        private static int encryptKey(char[]? key)
        {
            int tempKey;
            int totalKey = 0;
            for(int i = key.Length-1, k = 0; k < key.Length; i--)
            {
                tempKey = key[k++] - 0x30;
                for(int j = i; j > 0; j--)
                    tempKey *= 0xA;

                totalKey += tempKey;
            }

            return totalKey;
        }
        
        private static void MakeSerial(string str)
        {
            int Total = 0;
            foreach(char c in str)
            {
                Total += c * c;
                Total += c >> 1;
                Total -= c;
            }

            password = Total;
        }
        #endregion
    }

}